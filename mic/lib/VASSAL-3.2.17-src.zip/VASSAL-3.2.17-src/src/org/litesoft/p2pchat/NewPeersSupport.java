package org.litesoft.p2pchat;

public interface NewPeersSupport {
  void addNewPeer(PeerInfo pInfo);
}


