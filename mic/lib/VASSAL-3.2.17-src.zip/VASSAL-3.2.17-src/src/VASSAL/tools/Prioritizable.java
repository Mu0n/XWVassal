package VASSAL.tools;

public interface Prioritizable {
  int getPriority();
}
