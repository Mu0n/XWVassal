package VASSAL.tools;

public class HeapFinderDummy {
  public static void main(String[] args) {
  }
}

