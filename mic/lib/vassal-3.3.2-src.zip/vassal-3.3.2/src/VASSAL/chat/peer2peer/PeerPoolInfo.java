package VASSAL.chat.peer2peer;

/**
 * Date: Mar 12, 2003
 */
public interface PeerPoolInfo {
  public String getModuleName();
  public String getUserName();
}
